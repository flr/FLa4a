doc-tech
========

Technical document (sweave) about a4a methods
